<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_datakaryawan extends CI_Controller {

	private $result = [];

	function __construct(){
		parent::__construct();
        $this->result['status'] = "failed";
        $this->result['response'] = [];
        // Load model
    	$this->load->model('user_model');
    }

	public function login()
	{
		$username = $this->input->post("username") ?? '';
		$password = $this->input->post("password") ?? '';

		if ( empty($username) ){$this->result['response'] = "Username tidak boleh kosong.";echo json_encode($this->result);exit;}
		if ( empty($password) ){$this->result['response'] = "Password tidak boleh kosong.";echo json_encode($this->result);exit;}

		/* Cek username dan password di model*/
		$check = $this->user_model->getLogin($username, md5($password));
		if ( !$check )
        {
            $this->result['response'] = "Username tidak ditemukan.";
            echo json_encode($this->result);
            exit;
        }

        /* cek password */
        $data_pwd = $check[0]->password;
        if ( md5($password) != $data_pwd ){
            $this->result['response'] = "Password salah.";
            echo json_encode($this->result);
            exit;
        }

		$this->result['status']  = "done";
        $this->result['response'] = json_encode($check);
        echo json_encode($this->result);
        exit;
	}

	public function total_user(){
		/* Get total user*/
		$data = $this->user_model->total_user();

		$this->result['status']  = "done";
        $this->result['response'] = json_encode($data);
        echo json_encode($this->result);
        exit;
	}

	public function list_user(){
		/* Get total user*/
		$data = $this->user_model->list_user();

		$this->result['status']  = "done";
        $this->result['response'] = json_encode($data);
        echo json_encode($this->result);
        exit;
	}

	public function detail_user(){

		$id = $this->input->post("userId") ?? '';
		/* Get detail user*/
		$data = $this->user_model->detail_user($id);
		if ( !$data )
        {
            $this->result['response'] = "User tidak ditemukan.";
            echo json_encode($this->result);
            exit;
        }

		$this->result['status']  = "done";
        $this->result['response'] = json_encode($data);
        echo json_encode($this->result);
        exit;
	}

	function insert_user(){
		
		$nik 		= $this->input->post("nik") ?? '';
		$username 	= $this->input->post("username") ?? '';
		$name 		= $this->input->post("name") ?? '';
		$email 		= $this->input->post("email") ?? '';
		$photo 		= $this->input->post("photo") ?? '';
		$address 	= $this->input->post("address") ?? '';

		$data = [
            "nik"         	=> $nik,
            "username"      => $username,
            "password"      => md5("123456"),
            "name"    		=> $name,
            "email"      	=> $email,
            "address"      	=> $address,
        ];

        if ( $photo != '' ){
        	$target_dir = "upload";
	        #Create if directory not exist
	        if (!is_dir($target_dir)) {
	            @mkdir($target_dir);
	        }

	        $decoded = base64_decode($photo);
	        $filename = md5(time().$decoded).".jpg";
	        $fileupload = $target_dir."/".$filename;
	        file_put_contents($fileupload, $decoded);

            $data['photo'] = $fileupload;
        }

        $this->user_model->insert("user", $data);

        $this->result['status']  = "done";
        $this->result['response'] = "";
        echo json_encode($this->result);
        exit;
	}
	
	function update_user(){

		$id 		= $this->input->post("userId") ?? '';
		$nik 		= $this->input->post("nik") ?? '';
		$username 	= $this->input->post("username") ?? '';
		$name 		= $this->input->post("name") ?? '';
		$email 		= $this->input->post("email") ?? '';
		$photo 		= $this->input->post("photo") ?? '';
		$address 	= $this->input->post("address") ?? '';

		$check = $this->user_model->detail_user($id);

		$data = [
            "nik"         	=> $nik,
            "username"      => $username,
            "name"    		=> $name,
            "email"      	=> $email,
            "address"      	=> $address,
        ];

        if ( $photo != '' ){
        	$target_dir = "upload";
	        #Create if directory not exist
	        if (!is_dir($target_dir)) {
	            @mkdir($target_dir);
	        }

	        $decoded = base64_decode($photo);
	        $filename = md5(time().$decoded).".jpg";
	        $fileupload = $target_dir."/".$filename;
	        file_put_contents($fileupload, $decoded);

            $data['photo'] = $fileupload;
        }else{
        	$data['photo'] = $check[0]->photo;
        }

        $this->user_model->update("user", $data, ["id"=>$id]);

        $this->result['status']  = "done";
        $this->result['response'] = "";
        echo json_encode($this->result);
        exit;
	}
	
	function delete_user(){
		$id = $this->input->post("userId") ?? '';

        $this->user_model->delete("user", ["id"=>$id]);

        $this->result['status']  = "done";
        $this->result['response'] = "";
        echo json_encode($this->result);
        exit;
	}
}
