<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {

	protected $base_url = "https://api-datakaryawan.weirdsundries.com/";

	function getLogin($username = "", $password = ""){
		$this->db->select("*");
        $this->db->where("username", $username);
        $this->db->limit(1);
        $q = $this->db->get("user");
        return ($q->num_rows() == 0 ? FALSE : $q->result());
	}

	function total_user(){
		$this->db->select("COUNT(id) as total");
        $q = $this->db->get("user");
        return ($q->num_rows() == 0 ? FALSE : $q->result());
	}

	function list_user(){
		$this->db->select("*, CONCAT('".$this->base_url."', photo) as profile_picture");
        $q = $this->db->get("user");
        return ($q->num_rows() == 0 ? FALSE : $q->result());
	}

	function detail_user($id = ""){
		$this->db->select("*, CONCAT('".$this->base_url."', photo) as profile_picture");
		$this->db->where("id", $id);
        $q = $this->db->get("user");
        return ($q->num_rows() == 0 ? FALSE : $q->result());
	}

	function insert($table, $data){
		$this->db->insert($table, $data);
	}
	
	function update($table, $data, $where){
		$this->db->where($where);
		$this->db->update($table, $data);
	}
	
	function delete($table, $where){
		$this->db->where($where);
		$this->db->delete($table);
	}

}